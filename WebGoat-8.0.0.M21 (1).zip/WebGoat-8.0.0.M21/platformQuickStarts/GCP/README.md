# WebGoat on GCP!

This folder contains sub folders for the various ways you could deploy WebGoat on Google Cloud Platform

It is assumed:
1. You have a Google Cloud Platform Account
2. You can use Git
3. You can use a Linux/Mac/Google Cloud Shell


## GKE Docker

Uses GKE to run the latest DockerHub version of WebGoat8

## AppEngine

WIP